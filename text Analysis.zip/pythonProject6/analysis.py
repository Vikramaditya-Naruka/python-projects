import pandas as pd
import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from textblob import TextBlob
import textstat

# Download NLTK resources (required for sentence tokenization)
nltk.download('punkt')

# Read the list of article text files
article_files = [
    f"blackassign{i:04}.txt" for i in range(1, 101)
]

# Create a DataFrame to store the results
output_columns = [
    'URL_ID', 'POSITIVE SCORE', 'NEGATIVE SCORE', 'POLARITY SCORE', 'SUBJECTIVITY SCORE',
    'AVG SENTENCE LENGTH', 'PERCENTAGE OF COMPLEX WORDS', 'FOG INDEX',
    'AVG NUMBER OF WORDS PER SENTENCE', 'COMPLEX WORD COUNT', 'WORD COUNT',
    'SYLLABLE PER WORD', 'PERSONAL PRONOUNS', 'AVG WORD LENGTH'
]
output_df = pd.DataFrame(columns=output_columns)


# Function to compute textual analysis variables
def compute_textual_analysis(article_text):
    words = word_tokenize(article_text)
    sentences = sent_tokenize(article_text)

    word_count = len(words)
    sentence_count = len(sentences)
    avg_sentence_length = sum(len(sent.split()) for sent in sentences) / sentence_count

    long_word_count = textstat.long_word_count(article_text)  # Use long_word_count instead of complex_word_count
    percentage_complex_words = (long_word_count / word_count) * 100

    fog_index = textstat.gunning_fog(article_text)

    avg_words_per_sentence = word_count / sentence_count

    syllable_per_word = textstat.syllable_count(article_text) / word_count

    personal_pronouns = sum(1 for word in words if
                            word.lower() in ['i', 'me', 'my', 'mine', 'myself', 'you', 'your', 'yours', 'yourself',
                                             'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'we', 'us',
                                             'our', 'ours', 'ourselves', 'they', 'them', 'their', 'theirs',
                                             'themselves'])

    avg_word_length = sum(len(word) for word in words) / word_count

    blob = TextBlob(article_text)
    polarity_score = blob.sentiment.polarity
    subjectivity_score = blob.sentiment.subjectivity
    positive_score = len([sentence for sentence in blob.sentences if sentence.sentiment.polarity > 0])
    negative_score = len([sentence for sentence in blob.sentences if sentence.sentiment.polarity < 0])

    return positive_score, negative_score, polarity_score, subjectivity_score, avg_sentence_length, percentage_complex_words, fog_index, avg_words_per_sentence, long_word_count, word_count, syllable_per_word, personal_pronouns, avg_word_length


# Iterate through each article text file
for file_name in article_files:
    with open(file_name, "r", encoding="utf-8") as file:
        article_text = file.read()

    # Perform textual analysis
    results = compute_textual_analysis(article_text)

    # Append results to the output DataFrame
    url_id = file_name.split('.')[0]  # Extract URL_ID from file name
    output_df = pd.concat([output_df, pd.DataFrame([[url_id] + list(results)], columns=output_columns)],
                          ignore_index=True)

# Save the results to an Excel file
output_df.to_excel("Textual Analysis Results.xlsx", index=False)

print("Textual analysis complete. Results saved.")
