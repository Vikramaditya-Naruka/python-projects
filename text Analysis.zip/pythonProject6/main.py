import pandas as pd
import requests
from bs4 import BeautifulSoup
import re

# Read the input Excel file
input_file = "Input (1).xlsx"
df = pd.read_excel(input_file)

# Function to extract article text from URL
def extract_article_text(url):
    # Send a GET request to the URL
    response = requests.get(url)
    # Parse the HTML content
    soup = BeautifulSoup(response.content, 'html.parser')
    # Find the article title
    title = soup.find('title').get_text()
    # Find the main article content based on specific HTML structure or class
    article_content = soup.find('div', class_='td-ss-main-content')  # Adjust as per the actual HTML structure
    if article_content:
        # Find all paragraphs within the article content
        paragraphs = article_content.find_all('p')
        # Concatenate paragraphs to get the article text
        article_text = ' '.join([p.get_text() for p in paragraphs])
        return title, article_text
    else:
        print(f"Could not extract article text from {url}. Please check HTML structure.")
        return title, ""

# Iterate through each row in the DataFrame
for index, row in df.iterrows():
    url_id = row['URL_ID']
    url = row['URL']
    # Extract article text
    title, article_text = extract_article_text(url)
    # Write the article text to a text file
    with open(f"{url_id}.txt", "w", encoding="utf-8") as text_file:
        text_file.write(f"{title}\n\n{article_text}")
    print(f"Article extracted and saved for URL ID: {url_id}")

print("Extraction complete.")

